﻿
namespace TP_PAV1
{
    partial class AgregarUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCorreoNuevo = new System.Windows.Forms.TextBox();
            this.txtRepetirContraseñaNuevo = new System.Windows.Forms.TextBox();
            this.txtContraseñaNuevo = new System.Windows.Forms.TextBox();
            this.txtUsuarioNuevo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGuardarNuevoUsuario = new System.Windows.Forms.Button();
            this.btnCancelarNuevoUsuario = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCorreoNuevo);
            this.groupBox1.Controls.Add(this.txtRepetirContraseñaNuevo);
            this.groupBox1.Controls.Add(this.txtContraseñaNuevo);
            this.groupBox1.Controls.Add(this.txtUsuarioNuevo);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Location = new System.Drawing.Point(12, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(363, 162);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "NUEVO USUARIO";
            // 
            // txtCorreoNuevo
            // 
            this.txtCorreoNuevo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCorreoNuevo.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorreoNuevo.Location = new System.Drawing.Point(118, 114);
            this.txtCorreoNuevo.Name = "txtCorreoNuevo";
            this.txtCorreoNuevo.Size = new System.Drawing.Size(208, 18);
            this.txtCorreoNuevo.TabIndex = 7;
            // 
            // txtRepetirContraseñaNuevo
            // 
            this.txtRepetirContraseñaNuevo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRepetirContraseñaNuevo.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRepetirContraseñaNuevo.Location = new System.Drawing.Point(118, 83);
            this.txtRepetirContraseñaNuevo.Name = "txtRepetirContraseñaNuevo";
            this.txtRepetirContraseñaNuevo.Size = new System.Drawing.Size(208, 18);
            this.txtRepetirContraseñaNuevo.TabIndex = 6;
            // 
            // txtContraseñaNuevo
            // 
            this.txtContraseñaNuevo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtContraseñaNuevo.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContraseñaNuevo.Location = new System.Drawing.Point(118, 53);
            this.txtContraseñaNuevo.Name = "txtContraseñaNuevo";
            this.txtContraseñaNuevo.Size = new System.Drawing.Size(208, 18);
            this.txtContraseñaNuevo.TabIndex = 5;
            // 
            // txtUsuarioNuevo
            // 
            this.txtUsuarioNuevo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUsuarioNuevo.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuarioNuevo.Location = new System.Drawing.Point(118, 23);
            this.txtUsuarioNuevo.Name = "txtUsuarioNuevo";
            this.txtUsuarioNuevo.Size = new System.Drawing.Size(208, 18);
            this.txtUsuarioNuevo.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(55, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Correo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Repetir Contraseña";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Contraseña";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(55, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Usuario";
            // 
            // btnGuardarNuevoUsuario
            // 
            this.btnGuardarNuevoUsuario.BackColor = System.Drawing.Color.White;
            this.btnGuardarNuevoUsuario.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnGuardarNuevoUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarNuevoUsuario.Location = new System.Drawing.Point(236, 182);
            this.btnGuardarNuevoUsuario.Name = "btnGuardarNuevoUsuario";
            this.btnGuardarNuevoUsuario.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarNuevoUsuario.TabIndex = 1;
            this.btnGuardarNuevoUsuario.Text = "Aceptar";
            this.btnGuardarNuevoUsuario.UseVisualStyleBackColor = false;
            this.btnGuardarNuevoUsuario.Click += new System.EventHandler(this.btnGuardarNuevoUsuario_Click);
            // 
            // btnCancelarNuevoUsuario
            // 
            this.btnCancelarNuevoUsuario.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnCancelarNuevoUsuario.Location = new System.Drawing.Point(92, 182);
            this.btnCancelarNuevoUsuario.Name = "btnCancelarNuevoUsuario";
            this.btnCancelarNuevoUsuario.Size = new System.Drawing.Size(75, 23);
            this.btnCancelarNuevoUsuario.TabIndex = 2;
            this.btnCancelarNuevoUsuario.Text = "Cancelar";
            this.btnCancelarNuevoUsuario.UseVisualStyleBackColor = true;
            this.btnCancelarNuevoUsuario.Click += new System.EventHandler(this.btnCancelarNuevoUsuario_Click);
            // 
            // AgregarUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(20)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(391, 227);
            this.Controls.Add(this.btnCancelarNuevoUsuario);
            this.Controls.Add(this.btnGuardarNuevoUsuario);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AgregarUsuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AgregarUsuario";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.AgregarUsuario_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCorreoNuevo;
        private System.Windows.Forms.TextBox txtRepetirContraseñaNuevo;
        private System.Windows.Forms.TextBox txtContraseñaNuevo;
        private System.Windows.Forms.TextBox txtUsuarioNuevo;
        private System.Windows.Forms.Button btnGuardarNuevoUsuario;
        private System.Windows.Forms.Button btnCancelarNuevoUsuario;
    }
}