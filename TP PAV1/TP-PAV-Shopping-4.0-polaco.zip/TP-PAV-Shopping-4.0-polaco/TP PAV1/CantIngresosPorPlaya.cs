﻿namespace TP_PAV1
{


    partial class CantIngresosPorPlaya
    {
    }
}
