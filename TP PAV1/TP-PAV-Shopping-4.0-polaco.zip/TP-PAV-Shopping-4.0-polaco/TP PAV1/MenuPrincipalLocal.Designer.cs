﻿
namespace TP_PAV1
{
    partial class MenuPrincipalLocal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuPrincipalLocal));
            this.pnlMenuPrincipal = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCerrarSesionOK = new System.Windows.Forms.Button();
            this.btnSalirOK = new System.Windows.Forms.Button();
            this.pnlSalir = new System.Windows.Forms.Panel();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.pnlSistemaSubmenu = new System.Windows.Forms.Panel();
            this.pnlParkingSubmenu = new System.Windows.Forms.Panel();
            this.btnVehiculos = new System.Windows.Forms.Button();
            this.btnPlayas = new System.Windows.Forms.Button();
            this.btnParking = new System.Windows.Forms.Button();
            this.pnlComerciosSubmenu = new System.Windows.Forms.Panel();
            this.btnReportes = new System.Windows.Forms.Button();
            this.btnListados = new System.Windows.Forms.Button();
            this.btnComercios = new System.Windows.Forms.Button();
            this.pnlClientesSubmenu = new System.Windows.Forms.Panel();
            this.btnHistorial = new System.Windows.Forms.Button();
            this.btnVentas = new System.Windows.Forms.Button();
            this.btnClientes = new System.Windows.Forms.Button();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pctLogo = new System.Windows.Forms.PictureBox();
            this.pnlFormularioHijo = new System.Windows.Forms.Panel();
            this.pctLogoFondo = new System.Windows.Forms.PictureBox();
            this.pnlMenuPrincipal.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnlSalir.SuspendLayout();
            this.pnlParkingSubmenu.SuspendLayout();
            this.pnlComerciosSubmenu.SuspendLayout();
            this.pnlClientesSubmenu.SuspendLayout();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctLogo)).BeginInit();
            this.pnlFormularioHijo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctLogoFondo)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMenuPrincipal
            // 
            this.pnlMenuPrincipal.AutoScroll = true;
            this.pnlMenuPrincipal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(19)))));
            this.pnlMenuPrincipal.Controls.Add(this.panel1);
            this.pnlMenuPrincipal.Controls.Add(this.pnlSalir);
            this.pnlMenuPrincipal.Controls.Add(this.pnlSistemaSubmenu);
            this.pnlMenuPrincipal.Controls.Add(this.pnlParkingSubmenu);
            this.pnlMenuPrincipal.Controls.Add(this.btnParking);
            this.pnlMenuPrincipal.Controls.Add(this.pnlComerciosSubmenu);
            this.pnlMenuPrincipal.Controls.Add(this.btnComercios);
            this.pnlMenuPrincipal.Controls.Add(this.pnlClientesSubmenu);
            this.pnlMenuPrincipal.Controls.Add(this.btnClientes);
            this.pnlMenuPrincipal.Controls.Add(this.pnlLogo);
            this.pnlMenuPrincipal.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenuPrincipal.Location = new System.Drawing.Point(0, 0);
            this.pnlMenuPrincipal.Name = "pnlMenuPrincipal";
            this.pnlMenuPrincipal.Size = new System.Drawing.Size(265, 684);
            this.pnlMenuPrincipal.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnCerrarSesionOK);
            this.panel1.Controls.Add(this.btnSalirOK);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 650);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(265, 34);
            this.panel1.TabIndex = 11;
            // 
            // btnCerrarSesionOK
            // 
            this.btnCerrarSesionOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnCerrarSesionOK.FlatAppearance.BorderSize = 0;
            this.btnCerrarSesionOK.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnCerrarSesionOK.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnCerrarSesionOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarSesionOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrarSesionOK.ForeColor = System.Drawing.Color.White;
            this.btnCerrarSesionOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCerrarSesionOK.Location = new System.Drawing.Point(0, 0);
            this.btnCerrarSesionOK.Name = "btnCerrarSesionOK";
            this.btnCerrarSesionOK.Size = new System.Drawing.Size(132, 34);
            this.btnCerrarSesionOK.TabIndex = 9;
            this.btnCerrarSesionOK.Text = "Cerrar sesión";
            this.btnCerrarSesionOK.UseVisualStyleBackColor = false;
            // 
            // btnSalirOK
            // 
            this.btnSalirOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnSalirOK.FlatAppearance.BorderSize = 0;
            this.btnSalirOK.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnSalirOK.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnSalirOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalirOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirOK.ForeColor = System.Drawing.Color.White;
            this.btnSalirOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirOK.Location = new System.Drawing.Point(133, 0);
            this.btnSalirOK.Name = "btnSalirOK";
            this.btnSalirOK.Size = new System.Drawing.Size(132, 34);
            this.btnSalirOK.TabIndex = 10;
            this.btnSalirOK.Text = "Salir";
            this.btnSalirOK.UseVisualStyleBackColor = false;
            // 
            // pnlSalir
            // 
            this.pnlSalir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlSalir.Controls.Add(this.btnSalir);
            this.pnlSalir.Controls.Add(this.btnCerrarSesion);
            this.pnlSalir.Location = new System.Drawing.Point(0, 2559);
            this.pnlSalir.Name = "pnlSalir";
            this.pnlSalir.Size = new System.Drawing.Size(265, 45);
            this.pnlSalir.TabIndex = 8;
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnSalir.FlatAppearance.BorderSize = 0;
            this.btnSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnSalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.White;
            this.btnSalir.Location = new System.Drawing.Point(133, 7);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSalir.Size = new System.Drawing.Size(132, 38);
            this.btnSalir.TabIndex = 9;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = false;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnCerrarSesion.FlatAppearance.BorderSize = 0;
            this.btnCerrarSesion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnCerrarSesion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarSesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrarSesion.ForeColor = System.Drawing.Color.White;
            this.btnCerrarSesion.Location = new System.Drawing.Point(0, 7);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnCerrarSesion.Size = new System.Drawing.Size(132, 38);
            this.btnCerrarSesion.TabIndex = 8;
            this.btnCerrarSesion.Text = "Cerrar sesión";
            this.btnCerrarSesion.UseVisualStyleBackColor = false;
            // 
            // pnlSistemaSubmenu
            // 
            this.pnlSistemaSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(19)))));
            this.pnlSistemaSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSistemaSubmenu.Location = new System.Drawing.Point(0, 472);
            this.pnlSistemaSubmenu.Name = "pnlSistemaSubmenu";
            this.pnlSistemaSubmenu.Size = new System.Drawing.Size(265, 79);
            this.pnlSistemaSubmenu.TabIndex = 7;
            // 
            // pnlParkingSubmenu
            // 
            this.pnlParkingSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(19)))));
            this.pnlParkingSubmenu.Controls.Add(this.btnVehiculos);
            this.pnlParkingSubmenu.Controls.Add(this.btnPlayas);
            this.pnlParkingSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlParkingSubmenu.Location = new System.Drawing.Point(0, 388);
            this.pnlParkingSubmenu.Name = "pnlParkingSubmenu";
            this.pnlParkingSubmenu.Size = new System.Drawing.Size(265, 84);
            this.pnlParkingSubmenu.TabIndex = 5;
            // 
            // btnVehiculos
            // 
            this.btnVehiculos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnVehiculos.FlatAppearance.BorderSize = 0;
            this.btnVehiculos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnVehiculos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVehiculos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVehiculos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnVehiculos.Image = ((System.Drawing.Image)(resources.GetObject("btnVehiculos.Image")));
            this.btnVehiculos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVehiculos.Location = new System.Drawing.Point(0, 38);
            this.btnVehiculos.Name = "btnVehiculos";
            this.btnVehiculos.Size = new System.Drawing.Size(265, 38);
            this.btnVehiculos.TabIndex = 3;
            this.btnVehiculos.Text = "        Egreso de vehiculo";
            this.btnVehiculos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVehiculos.UseVisualStyleBackColor = true;
            this.btnVehiculos.Click += new System.EventHandler(this.btnVehiculos_Click);
            // 
            // btnPlayas
            // 
            this.btnPlayas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPlayas.FlatAppearance.BorderSize = 0;
            this.btnPlayas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnPlayas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlayas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlayas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnPlayas.Image = ((System.Drawing.Image)(resources.GetObject("btnPlayas.Image")));
            this.btnPlayas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPlayas.Location = new System.Drawing.Point(0, 0);
            this.btnPlayas.Name = "btnPlayas";
            this.btnPlayas.Size = new System.Drawing.Size(265, 38);
            this.btnPlayas.TabIndex = 2;
            this.btnPlayas.Text = "        Ingreso de vehiculo";
            this.btnPlayas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPlayas.UseVisualStyleBackColor = true;
            this.btnPlayas.Click += new System.EventHandler(this.btnPlayas_Click);
            // 
            // btnParking
            // 
            this.btnParking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnParking.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnParking.FlatAppearance.BorderSize = 0;
            this.btnParking.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnParking.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnParking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParking.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnParking.ForeColor = System.Drawing.Color.White;
            this.btnParking.Image = ((System.Drawing.Image)(resources.GetObject("btnParking.Image")));
            this.btnParking.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnParking.Location = new System.Drawing.Point(0, 350);
            this.btnParking.Name = "btnParking";
            this.btnParking.Size = new System.Drawing.Size(265, 38);
            this.btnParking.TabIndex = 4;
            this.btnParking.Text = "      Parking";
            this.btnParking.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnParking.UseVisualStyleBackColor = false;
            this.btnParking.Click += new System.EventHandler(this.btnParking_Click);
            // 
            // pnlComerciosSubmenu
            // 
            this.pnlComerciosSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(19)))));
            this.pnlComerciosSubmenu.Controls.Add(this.btnReportes);
            this.pnlComerciosSubmenu.Controls.Add(this.btnListados);
            this.pnlComerciosSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlComerciosSubmenu.Location = new System.Drawing.Point(0, 266);
            this.pnlComerciosSubmenu.Name = "pnlComerciosSubmenu";
            this.pnlComerciosSubmenu.Size = new System.Drawing.Size(265, 84);
            this.pnlComerciosSubmenu.TabIndex = 3;
            // 
            // btnReportes
            // 
            this.btnReportes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnReportes.FlatAppearance.BorderSize = 0;
            this.btnReportes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnReportes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReportes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReportes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnReportes.Image = ((System.Drawing.Image)(resources.GetObject("btnReportes.Image")));
            this.btnReportes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReportes.Location = new System.Drawing.Point(0, 38);
            this.btnReportes.Name = "btnReportes";
            this.btnReportes.Size = new System.Drawing.Size(265, 38);
            this.btnReportes.TabIndex = 3;
            this.btnReportes.Text = "        Listados";
            this.btnReportes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReportes.UseVisualStyleBackColor = true;
            this.btnReportes.Click += new System.EventHandler(this.btnReportes_Click);
            // 
            // btnListados
            // 
            this.btnListados.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnListados.FlatAppearance.BorderSize = 0;
            this.btnListados.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnListados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListados.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnListados.Image = ((System.Drawing.Image)(resources.GetObject("btnListados.Image")));
            this.btnListados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnListados.Location = new System.Drawing.Point(0, 0);
            this.btnListados.Name = "btnListados";
            this.btnListados.Size = new System.Drawing.Size(265, 38);
            this.btnListados.TabIndex = 2;
            this.btnListados.Text = "        Estadisticas";
            this.btnListados.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnListados.UseVisualStyleBackColor = true;
            this.btnListados.Click += new System.EventHandler(this.btnListados_Click);
            // 
            // btnComercios
            // 
            this.btnComercios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnComercios.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnComercios.FlatAppearance.BorderSize = 0;
            this.btnComercios.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnComercios.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnComercios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComercios.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComercios.ForeColor = System.Drawing.Color.White;
            this.btnComercios.Image = ((System.Drawing.Image)(resources.GetObject("btnComercios.Image")));
            this.btnComercios.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnComercios.Location = new System.Drawing.Point(0, 228);
            this.btnComercios.Name = "btnComercios";
            this.btnComercios.Size = new System.Drawing.Size(265, 38);
            this.btnComercios.TabIndex = 2;
            this.btnComercios.Text = "      Listado/Estadistica";
            this.btnComercios.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnComercios.UseVisualStyleBackColor = false;
            this.btnComercios.Click += new System.EventHandler(this.btnComercios_Click_1);
            // 
            // pnlClientesSubmenu
            // 
            this.pnlClientesSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(19)))));
            this.pnlClientesSubmenu.Controls.Add(this.btnHistorial);
            this.pnlClientesSubmenu.Controls.Add(this.btnVentas);
            this.pnlClientesSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlClientesSubmenu.Location = new System.Drawing.Point(0, 144);
            this.pnlClientesSubmenu.Name = "pnlClientesSubmenu";
            this.pnlClientesSubmenu.Size = new System.Drawing.Size(265, 84);
            this.pnlClientesSubmenu.TabIndex = 1;
            // 
            // btnHistorial
            // 
            this.btnHistorial.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHistorial.FlatAppearance.BorderSize = 0;
            this.btnHistorial.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnHistorial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHistorial.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHistorial.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnHistorial.Image = ((System.Drawing.Image)(resources.GetObject("btnHistorial.Image")));
            this.btnHistorial.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHistorial.Location = new System.Drawing.Point(0, 38);
            this.btnHistorial.Name = "btnHistorial";
            this.btnHistorial.Size = new System.Drawing.Size(265, 38);
            this.btnHistorial.TabIndex = 3;
            this.btnHistorial.Text = "        Historial";
            this.btnHistorial.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHistorial.UseVisualStyleBackColor = true;
            this.btnHistorial.Click += new System.EventHandler(this.btnHistorial_Click);
            // 
            // btnVentas
            // 
            this.btnVentas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnVentas.FlatAppearance.BorderSize = 0;
            this.btnVentas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnVentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVentas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVentas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnVentas.Image = ((System.Drawing.Image)(resources.GetObject("btnVentas.Image")));
            this.btnVentas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVentas.Location = new System.Drawing.Point(0, 0);
            this.btnVentas.Name = "btnVentas";
            this.btnVentas.Size = new System.Drawing.Size(265, 38);
            this.btnVentas.TabIndex = 2;
            this.btnVentas.Text = "        Ventas";
            this.btnVentas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVentas.UseVisualStyleBackColor = true;
            this.btnVentas.Click += new System.EventHandler(this.btnVentas_Click);
            // 
            // btnClientes
            // 
            this.btnClientes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnClientes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnClientes.FlatAppearance.BorderSize = 0;
            this.btnClientes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.btnClientes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(187)))), ((int)(((byte)(227)))));
            this.btnClientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClientes.ForeColor = System.Drawing.Color.White;
            this.btnClientes.Image = ((System.Drawing.Image)(resources.GetObject("btnClientes.Image")));
            this.btnClientes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClientes.Location = new System.Drawing.Point(0, 106);
            this.btnClientes.Name = "btnClientes";
            this.btnClientes.Size = new System.Drawing.Size(265, 38);
            this.btnClientes.TabIndex = 1;
            this.btnClientes.Text = "      Ventas";
            this.btnClientes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClientes.UseVisualStyleBackColor = false;
            this.btnClientes.Click += new System.EventHandler(this.btnClientes_Click_1);
            // 
            // pnlLogo
            // 
            this.pnlLogo.Controls.Add(this.label2);
            this.pnlLogo.Controls.Add(this.label1);
            this.pnlLogo.Controls.Add(this.pctLogo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(265, 106);
            this.pnlLogo.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MV Boli", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.label2.Location = new System.Drawing.Point(112, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "BUY ALL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MV Boli", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(139)))), ((int)(((byte)(204)))));
            this.label1.Location = new System.Drawing.Point(106, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "SHOPPING";
            // 
            // pctLogo
            // 
            this.pctLogo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pctLogo.Image = ((System.Drawing.Image)(resources.GetObject("pctLogo.Image")));
            this.pctLogo.Location = new System.Drawing.Point(0, 0);
            this.pctLogo.Name = "pctLogo";
            this.pctLogo.Size = new System.Drawing.Size(106, 106);
            this.pctLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctLogo.TabIndex = 0;
            this.pctLogo.TabStop = false;
            // 
            // pnlFormularioHijo
            // 
            this.pnlFormularioHijo.Controls.Add(this.pctLogoFondo);
            this.pnlFormularioHijo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFormularioHijo.Location = new System.Drawing.Point(265, 0);
            this.pnlFormularioHijo.Name = "pnlFormularioHijo";
            this.pnlFormularioHijo.Size = new System.Drawing.Size(555, 684);
            this.pnlFormularioHijo.TabIndex = 3;
            // 
            // pctLogoFondo
            // 
            this.pctLogoFondo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pctLogoFondo.Image = ((System.Drawing.Image)(resources.GetObject("pctLogoFondo.Image")));
            this.pctLogoFondo.Location = new System.Drawing.Point(99, 163);
            this.pctLogoFondo.Name = "pctLogoFondo";
            this.pctLogoFondo.Size = new System.Drawing.Size(350, 350);
            this.pctLogoFondo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctLogoFondo.TabIndex = 1;
            this.pctLogoFondo.TabStop = false;
            // 
            // MenuPrincipalLocal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(820, 684);
            this.Controls.Add(this.pnlFormularioHijo);
            this.Controls.Add(this.pnlMenuPrincipal);
            this.MinimumSize = new System.Drawing.Size(836, 723);
            this.Name = "MenuPrincipalLocal";
            this.Text = "Menu Principal";
            this.pnlMenuPrincipal.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.pnlSalir.ResumeLayout(false);
            this.pnlParkingSubmenu.ResumeLayout(false);
            this.pnlComerciosSubmenu.ResumeLayout(false);
            this.pnlClientesSubmenu.ResumeLayout(false);
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctLogo)).EndInit();
            this.pnlFormularioHijo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pctLogoFondo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMenuPrincipal;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCerrarSesionOK;
        private System.Windows.Forms.Button btnSalirOK;
        private System.Windows.Forms.Panel pnlSalir;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.Panel pnlSistemaSubmenu;
        private System.Windows.Forms.Panel pnlParkingSubmenu;
        private System.Windows.Forms.Button btnVehiculos;
        private System.Windows.Forms.Button btnPlayas;
        private System.Windows.Forms.Button btnParking;
        private System.Windows.Forms.Panel pnlComerciosSubmenu;
        private System.Windows.Forms.Button btnReportes;
        private System.Windows.Forms.Button btnListados;
        private System.Windows.Forms.Button btnComercios;
        private System.Windows.Forms.Panel pnlClientesSubmenu;
        private System.Windows.Forms.Button btnHistorial;
        private System.Windows.Forms.Button btnVentas;
        private System.Windows.Forms.Button btnClientes;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pctLogo;
        private System.Windows.Forms.Panel pnlFormularioHijo;
        private System.Windows.Forms.PictureBox pctLogoFondo;
    }
}