﻿namespace TP_PAV1
{


    partial class CantClientesXProfesiones
    {
        partial class ClientesXProfesionesDataTable
        {
        }
    }
}
